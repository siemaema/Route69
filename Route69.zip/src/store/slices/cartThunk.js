import {
  addToCart,
  removeFromCart,
  increseQuantity,
  decreseQuantity,
  setCartFromServer,
  clearCart,
} from "./cartSlice";

// Pomocnik do localStorage
const saveCartToLocalStorage = (cart) => {
  localStorage.setItem("dev_cart", JSON.stringify(cart));
};

export const updateCartAndSync = (actionType, payload) => async (dispatch, getState) => {
  switch (actionType) {
    case "add":
      dispatch(addToCart({ ...payload, quantity: 1 }));
      break;
    case "remove":
      dispatch(removeFromCart(payload));
      break;
    case "increase":
      dispatch(increseQuantity(payload));
      break;
    case "decrease":
      dispatch(decreseQuantity(payload));
      break;
    case "clear":
      dispatch(clearCart());
      break;
    default:
      console.warn("Nieznana akcja koszyka:", actionType);
      return;
  }

  // Zapisz lokalnie zamiast na serwer
  const { cart } = getState();
  saveCartToLocalStorage(cart.items);
};

export const loadCartFromUser = () => (dispatch) => {
  const stored = localStorage.getItem("dev_cart");
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      dispatch(setCartFromServer(parsed));
    } catch (err) {
      console.error("Błąd parsowania dev_cart:", err);
    }
  }
};
